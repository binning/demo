<template>
    <div>
        <div class="crumbs">
            <el-breadcrumb separator="/">
                <el-breadcrumb-item><i class="el-icon-date"></i> 客服中心</el-breadcrumb-item>
                <el-breadcrumb-item>来电记录</el-breadcrumb-item>
            </el-breadcrumb>
        </div>
        来电记录页面
    </div>
</template>
<script>
export default {};
</script>
<style>
</style>