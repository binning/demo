<template>
    <div>
        <div class="crumbs">
            <el-breadcrumb separator="/">
                <el-breadcrumb-item><i class="el-icon-date"></i> 催收管理</el-breadcrumb-item>
                <el-breadcrumb-item>历史催收</el-breadcrumb-item>
            </el-breadcrumb>
        </div>
        历史催收页面
    </div>
</template>
<script>
export default {
    
}
</script>
<style>

</style>