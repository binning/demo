<template>
    <div>
        <div class="crumbs">
            <el-breadcrumb separator="/">
                <el-breadcrumb-item><i class="el-icon-date"></i> 产品管理</el-breadcrumb-item>
                <el-breadcrumb-item>产品数据</el-breadcrumb-item>
            </el-breadcrumb>
        </div>
        产品数据页面
    </div>
</template>
<script>
export default {
    
}
</script>
<style>

</style>