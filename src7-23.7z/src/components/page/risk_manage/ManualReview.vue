<template>
    <div>
        <div class="crumbs">
            <el-breadcrumb separator="/">
                <el-breadcrumb-item><i class="el-icon-date"></i> 风控审核</el-breadcrumb-item>
                <el-breadcrumb-item>人工复审</el-breadcrumb-item>
            </el-breadcrumb>
        </div>
        人工复审页面
    </div>
</template>
<script>
export default {
    
}
</script>
<style>

</style>