<template>
    <div>
        <div class="crumbs">
            <el-breadcrumb separator="/">
                <el-breadcrumb-item><i class="el-icon-date"></i> 统计中心</el-breadcrumb-item>
                <el-breadcrumb-item>订单统计</el-breadcrumb-item>
            </el-breadcrumb>
        </div>
        订单统计页面
    </div>
</template>
<script>
export default {
    
}
</script>
<style>

</style>