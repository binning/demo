<template>
    <div>
        <div class="crumbs">
            <el-breadcrumb separator="/">
                <el-breadcrumb-item><i class="el-icon-date"></i> 系统管理</el-breadcrumb-item>
                <el-breadcrumb-item>人事结构</el-breadcrumb-item>
            </el-breadcrumb>
        </div>
        人事结构页面
    </div>
</template>
<script>
export default {
    
}
</script>
<style>

</style>