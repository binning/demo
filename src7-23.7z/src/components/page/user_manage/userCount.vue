<template>
    <div>
        <div class="crumbs">
            <el-breadcrumb separator="/">
                <el-breadcrumb-item><i class="el-icon-date"></i> 用户管理</el-breadcrumb-item>
                <el-breadcrumb-item>用户统计</el-breadcrumb-item>
            </el-breadcrumb>
        </div>
        用户统计
    </div>
</template>
<script>
export default {
    
}
</script>
<style>

</style>